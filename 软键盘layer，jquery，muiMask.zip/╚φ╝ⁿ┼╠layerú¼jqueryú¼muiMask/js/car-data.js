var carData = [
	{
		value: 'dazhong',
		text: '大众',
		children: [
			{
				value: 'polo',
				text: 'POLO',
				children: [
					{
						value: '2018-m',
						text: '2018手动'
					},
					{
						value: '2018-a',
						text: '2018自动'
					}
				]
			},
			{
				value: 'santana',
				text: '桑塔纳',
				children: [
					{
						value: '2017-m',
						text: '2017手动'
					},
					{
						value: '2017-a',
						text: '2017 自动'
					}
				]
			}
		]
	},
	{
		value: 'fengtian',
		text: '丰田',
		children: [
			{
				value: 'kaimeirui',
				text: '凯美瑞',
				children: [
					{
						value: '2018-m',
						text: '2018手动'
					},
					{
						value: '2018-a',
						text: '2018自动'
					}
				]
			},
			{
				value: 'kaluola',
				text: '卡罗拉',
				children: [
					{
						value: '2017-m',
						text: '2017手动'
					},
					{
						value: '2017-a',
						text: '2017 自动'
					}
				]
			}
		]
	},
	{
		value: 'benchi',
		text: '奔驰',
		children: [
			{
				value: 'benchiaji',
				text: '奔驰A级',
				children: [
					{
						value: '2018-m',
						text: '2018手动'
					},
					{
						value: '2018-a',
						text: '2018自动'
					}
				]
			},
			{
				value: 'benchicji',
				text: '奔驰C级',
				children: [
					{
						value: '2017-m',
						text: '2017手动'
					},
					{
						value: '2017-a',
						text: '2017 自动'
					}
				]
			}
		]
	}
]
